<?php
	error_reporting(E_ALL);
  header("Content-Type: text/html; charset=utf-8");
  print "Hello!";
  //require_once '../config/connect.php';
  
  $url = "http://www.startupjobs.cz/map.php";
  $data = new SimpleXMLElement($url, NULL, TRUE);
			
	$insert = $update = array();
  foreach ($data as $out_ns) {
    $ns = $out_ns->getNamespaces(TRUE);
    $child = $out_ns->children();
    
    echo $child->city;
    /*
    # uložení nových dat / update dat
		$stm = $db->prepare('SELECT id FROM `startups` WHERE id = :id');
		$params = array(':id' => $child->id);
		$ok = $stm->execute($params);
		$row = $stm->fetch(PDO::FETCH_ASSOC);
		  //echo $child->name;
		# přidání nebo update záznamu
    if ($child->id == $row->id) {
			//$update[] = "";	 		
		}
		else {
			$insert[] = '(' . $row->name . ', ' . $row->description . ', ' . $row->url . ', ' . $row->address . ', ' . $row->city . ')';
		}  */
  }     
		       	//print_r($data);
	# spuštění hromadného zápisu dat do databáze
	if ($insert != "") {
		$imPlode = imPlode(', ', $insert);
		$db->exec("
			INSERT INTO `statups` 
		  (name, description, url, address, city) 
			VALUES " . $imPlode ."");	
			
		echo "Bazinga!";	
	} 
		
	# spuštění hromadného updatu dat do databáze

     /*
    foreach ($child as $out) {
	     echo $out . "<br />";
    }   */
    
?>