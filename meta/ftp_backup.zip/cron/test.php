<?php
  header("Content-Type: text/html; charset=utf-8");
  $url = "http://www.startupjobs.cz/map.php";
  $data = new SimpleXMLElement($url, NULL, TRUE);

  foreach ($data as $out_ns) {
    $ns = $out_ns->getNamespaces(TRUE);
    $child = $out_ns->children();
       echo $child->city;
    echo "<hr>";
     /*
    foreach ($child as $out) {
	     echo $out . "<br />";
    }   */
  }
?>