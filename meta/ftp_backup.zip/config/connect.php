<?php
	//phpMyAdmin: mysql-jimmy.onebit.cz
  //http://blog.petrovsky.cz/98/databaze-v-php-prace-s-pdo/
  function easyPDO($dbhost, $dbname, $dbuser = 'root', $dbpass = '', $dbtype = 'mysql') {
    $db = new PDO($dbtype . ':host=' . $dbhost . ';dbname=' . $dbname, $dbuser, $dbpass);
    return $db;
  }
  
  try {
    $db = easyPDO('127.0.0.1', 'freshgolfcz9', 'freshgolf.cz.10', 'StartupJobsMDB10');
  }
  catch (PDOException $err) {
    echo "Chyba spojeni: " . $err->getMessage();
  }


?>